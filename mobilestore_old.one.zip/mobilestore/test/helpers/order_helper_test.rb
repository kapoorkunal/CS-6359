require 'test_helper'

class OrderHelperTest < ActionView::TestCase
end
