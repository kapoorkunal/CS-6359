require 'test_helper'

class CustomerHelperTest < ActionView::TestCase
end
