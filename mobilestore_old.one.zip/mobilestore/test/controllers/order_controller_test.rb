require 'test_helper'

class OrderControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
