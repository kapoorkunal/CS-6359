require 'test_helper'

class ProductControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
