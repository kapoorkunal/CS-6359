class ChangeColumnName < ActiveRecord::Migration
  def change
  
  end
end
