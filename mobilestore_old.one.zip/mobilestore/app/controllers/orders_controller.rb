class OrdersController < ApplicationController

	def index
		@orders = Order.where("username = ? ", session[:username])

		
		@orderdetails = Order.joins(:order_details).uniq(:id).where("username = ? ", session[:username])
	end
end
