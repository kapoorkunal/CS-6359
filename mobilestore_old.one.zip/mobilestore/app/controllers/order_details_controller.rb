class OrderDetailsController < ApplicationController
	def product
	end	

	def new
		@order_details = OrderDetail.where("orderId = ? ", session[:order_id])
		@prodId = params[:prodId] 
		$product = Product.find(params[:prodId])
	end
	
	
    def edit		
	  @order_detail = OrderDetail.find(params[:id])
	end
	
	def update
  		@order_details = OrderDetail.find(params[:id])
		@order_detail.update(order_details_params)
		redirect_to checkout_path
 	end 
	
	def destroy
    	@order_detail = OrderDetail.find(params[:id])
    	@order_detail.destroy
 
    	redirect_to checkout_path
  	end
	
	def create 
		@order_detail = OrderDetail.new(order_details_params)
	 	@order_detail.productId = $product.id
		@order_detail.Product_id = $product.id

		@product = Product.find($product.id)

		@order_detail.productname = @product.name
		@order_detail.productprice = @product.price
	 	
	 	if !session[:order_id].nil?
	      @currentOrder = Order.find(session[:order_id])
	    else
	      @currentOrder = Order.new
	      @currentOrder.save
	      session[:order_id] = @currentOrder.id
	    end

	 	@order_detail.orderId = @currentOrder.id
	 	@order_detail.Order_id = @currentOrder.id
	  	if @order_detail.save

	    	redirect_to $product
	  	else
	    	render 'new'
	  	end
	end

	def index
		@order_details = OrderDetail.where("orderId = ? ", session[:order_id])
	end

	private
  	def order_details_params
    	params.require(:order_detail).permit(:orderId, :quantity)
  	end

end
