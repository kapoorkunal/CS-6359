class CheckoutController < ApplicationController

	def show
		@total = 0
		@order_details = OrderDetail.where("orderId = ? ", session[:order_id])
		@order_details.each do |orderDetail|
	      @prod = Product.where("id = ? ", orderDetail.productId).first
	      @total = @total + (@prod.price * orderDetail.quantity)
	    end
	end

	def success
		@total = 0
		@order_details = OrderDetail.where("orderId = ? ", session[:order_id])
		@order_details.each do |orderDetail|
	      @prod = Product.where("id = ? ", orderDetail.productId).first
	      @total = @total + (@prod.price * orderDetail.quantity)
		  @prod.quantity = @prod.quantity - orderDetail.quantity
		  @prod.save
	    end
		@orderID = session[:order_id]
		@order = Order.find(session[:order_id])
		@order.date = Time.now
		@order.amount = @total
		@order.username = current_user.email
		@order.save	
		@order_details = OrderDetail.where("orderId = ? ", session[:order_id])
		session[:order_id] = nil
	end 
end
