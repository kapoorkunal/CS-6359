class CustomerController < ApplicationController
end
